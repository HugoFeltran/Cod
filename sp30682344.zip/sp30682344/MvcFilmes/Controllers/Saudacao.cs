using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
namespace MvcFilmes.Controllers;

public class Saudacao : Controller
{
    public IActionResult Index()
        {
            return View();
        }


    public IActionResult Saudacao1(string nome)
        {
            ViewData["Message"]= ($"{nome},seja bem vindo ao IFSP");
            return View();
        }

            public IActionResult Saudacao2(string nome, int qtd)
        {
            ViewData["Message"]= ($"Olá {nome},você deverá desenvolver {qtd} atividade ao longo do semestre");
            return View();
        }

        public IActionResult Saudacao3(string name, string periodo)
{
            string horario = "";

            if (periodo == "Matutino")
            {
            horario = "07h:00m as 11h45m";
            ViewData["Message"] = ($"SEDCITEC - 18 a 22 de Setembro - Ola {name}, como voce esta no periodo {periodo}, devera participar da SEDCITEC no periodo das {horario}");
            return View();
            }
            else if (periodo == "Vespertino")
            {
            horario = "13h:15m as 18h:00m";
            ViewData["Message"] = ($"SEDCITEC - 18 a 22 de Setembro - Ola {name}, como voce esta no periodo {periodo}, devera participar da SEDCITEC no periodo das {horario}");
            return View();
            }
            else
            {
            ViewData["Message"] = "Periodo Invalido";
            return View();
            }

            
            }
}